package com.TechM;




public class Country implements Comparable<Country>{
	
	private String country;
	private int gold;
	private int silver;
	private int bronze;
	
	public Country(String country,int gold,int silver,int bronze){
		this.country = country;
		this.gold = gold;
		this.silver = silver;
		this.bronze = bronze;
		
		
	}
	public String getCountry() {
//		System.out.println("get this.country="+this.country);
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
//		System.out.println("set this.country="+this.country);
	}
	public int getGold() {
//		System.out.println("get this.gold="+this.gold);
		return gold;
	}
	public void setGold(int gold) {
		this.gold = gold;
//		System.out.println("set this.gold="+this.gold);
	}
	public int getSilver() {
//		System.out.println("get this.silver="+this.silver);
		return silver;
	}
	public void setSilver(int silver) {
		this.silver = silver;
//		System.out.println("set this.silver="+this.silver);
	}
	public int getBronze() {
//		System.out.println("Get this.bronze="+this.bronze);
		return bronze;
	}
	public void setBronze(int bronze) {
		this.bronze = bronze;
//		System.out.println("set this.bronze="+this.bronze);
	}
	/**
	* Compare a given Country with this object.
	* If gold of this object is 
	* greater than the received object,
	* then this object is greater than the other.
	* 1. positive � this object is greater than o1
	* 2. zero � this object equals to o1
	* 3. negative � this object is less than o1
	*/

	
	public int compareTo(Country o) {
		return this.gold - o.gold;
		//return this.getName().compareTo(o.getName());
	}
	

}
