package com.TechM;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CSVRead {

	public static void main(String[] args) {

		CSVRead obj = new CSVRead();
		obj.run();

	}

	public void run() {

		String csvFile = "D:\\techm nna\\Interview\\WS\\Stock_Country\\Country_Stock.csv";
		//Path may be different where u keep csv file ,plz check out path
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		//Map<String, Country> map = new HashMap<String, Country>();
		List<Country> col = new ArrayList<Country>();

		try {

			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {
				// use comma as separator
				/*
				 * String[] country = line.split(cvsSplitBy);
				 * System.out.println("Country [code= " + country[4]+ " , name="
				 * + country[5] + "]");
				 */
				String[] country = line.split(cvsSplitBy);
				if (country != null && !country[0].equals("Country")) {
					col.add(new Country(country[0], convertInt(country[1]),
							convertInt(country[2]), convertInt(country[3])));
					// System.out.println("countryObj : "+countryObj.getCountry()+","+countryObj.getGold()+","+countryObj.getSilver()+","+countryObj.getBronze());

				}
			}

			System.out.println("----------------------------");
			System.out.println("	Before sort");
			System.out.println("----------------------------");
			System.out.println("Country\t Gold\t Silver\t Bronze\t");
			for (Country c : col) {
				System.out.println(c.getCountry() + "\t " + c.getGold() + "\t "
						+ c.getSilver() + "\t " + c.getBronze());
			}

			Collections.sort(col);
			System.out.println("----------------------------");
			System.out.println("	After sort");
			System.out.println("----------------------------");
			System.out.println("Country\t Gold\t Silver\t Bronze\t");
			for (Country c : col) {
				System.out.println(c.getCountry() + "\t " + c.getGold() + "\t "
						+ c.getSilver() + "\t " + c.getBronze());
			}

			// CSV file writing

			File file = new File("D:\\techm nna\\Interview\\WS\\Stock_Country\\Sorted_Country_Stock.csv");
			if (file.exists()) {
				file.delete();
			}
			BufferedWriter writer = new BufferedWriter(new FileWriter(file,
					true));
			String header = "Country,gold,silver,bronze";
			writer.write(header);
			writer.newLine();
			writer.flush();
			for (Country c : col) {
				String str = "";
				str = c.getCountry() + "," + c.getGold() + "," + c.getSilver()
						+ "," + c.getBronze();
				writer.write(str);
				writer.newLine();
				writer.flush();
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

	private int convertInt(String stockValue) {
		int stockIntValue = 0;
		try {
			if (stockValue != null && stockValue.length() > 0) {
				stockIntValue = Integer.parseInt(stockValue);
			}
			// System.out.println("stockIntValue : "+stockIntValue);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return stockIntValue;

	}

}
