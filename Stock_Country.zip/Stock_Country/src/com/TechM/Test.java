package com.TechM;

import java.awt.List;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class Test {
	public static void main(String[] args) {
		int arr[]={1,2,3};
		List li=(List) Arrays.asList(arr);
//		Iterator<li> it=li
		System.out.println(li);
	}
	

}
